<?php
// Front controller: every request lands here.
require_once dirname(__DIR__) . '/core/bootstrap.php';

$path = rtrim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/') ?: '/';

$routes = [
    '/'                => 'login',
    '/login'           => 'login',
    '/logout'          => 'logout',
    '/admin/dashboard' => 'admin/dashboard',
    // Step 3+: '/admin/bookings', '/admin/providers', '/admin/services' ...
];

if (!isset($routes[$path])) { http_response_code(404); exit('404 – Page not found.'); }
require dirname(__DIR__) . '/modules/' . $routes[$path] . '.php';
