<?php
audit_log('logout', 'User logged out');
Auth::logout();
