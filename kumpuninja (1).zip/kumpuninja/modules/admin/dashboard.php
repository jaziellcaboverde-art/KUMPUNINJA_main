<?php
Auth::requireRole(ROLE_ADMIN);
$pdo = db();

$pending   = (int)$pdo->query("SELECT COUNT(*) FROM bookings WHERE status='pending'")->fetchColumn();
$upcoming  = (int)$pdo->query("SELECT COUNT(*) FROM bookings WHERE status IN ('accepted','assigned','in_progress') AND preferred_date >= CURRENT_DATE")->fetchColumn();
$doneMonth = (int)$pdo->query("SELECT COUNT(*) FROM bookings WHERE status='completed' AND date_trunc('month', preferred_date) = date_trunc('month', CURRENT_DATE)")->fetchColumn();
$revenue   = (float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM payments WHERE status='paid'")->fetchColumn();
$providers = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='provider' AND is_active AND is_available")->fetchColumn();

$byStatus = array_fill_keys(BOOKING_STATUSES, 0);
foreach ($pdo->query('SELECT status, COUNT(*) c FROM bookings GROUP BY status') as $r) $byStatus[$r['status']] = (int)$r['c'];
$maxStatus = max(1, max($byStatus));

$recent = $pdo->query("
    SELECT b.id, b.status, b.preferred_date, b.preferred_time, b.address,
           s.name AS service, c.name AS customer, p.name AS provider
    FROM bookings b
    JOIN services s ON s.id = b.service_id
    JOIN users c ON c.id = b.customer_id
    LEFT JOIN users p ON p.id = b.provider_id
    ORDER BY b.created_at DESC, b.id DESC LIMIT 8")->fetchAll();

$pageTitle = 'Dashboard'; $activeNav = 'dashboard';
ob_start(); ?>
<section class="kpis">
    <div class="kpi warn"><span>New requests</span><b><?= $pending ?></b><small>waiting for your review</small></div>
    <div class="kpi"><span>Upcoming jobs</span><b><?= $upcoming ?></b><small>accepted / assigned</small></div>
    <div class="kpi"><span>Completed this month</span><b><?= $doneMonth ?></b><small>finished jobs</small></div>
    <div class="kpi"><span>Collected</span><b><?= peso($revenue) ?></b><small><?= $providers ?> providers available</small></div>
</section>

<section class="grid">
    <div class="card">
        <h3>Recent booking requests</h3>
        <table>
            <thead><tr><th>Customer</th><th>Service</th><th>Schedule</th><th>Provider</th><th>Status</th></tr></thead>
            <tbody>
            <?php foreach ($recent as $r): ?>
                <tr>
                    <td><?= e($r['customer']) ?><br><small><?= e($r['address']) ?></small></td>
                    <td><?= e($r['service']) ?></td>
                    <td><?= date('M j', strtotime($r['preferred_date'])) ?><br><small><?= e($r['preferred_time']) ?></small></td>
                    <td><?= $r['provider'] ? e($r['provider']) : '<small>Unassigned</small>' ?></td>
                    <td><span class="pill s-<?= e($r['status']) ?>"><?= e(status_label($r['status'])) ?></span></td>
                </tr>
            <?php endforeach; if (!$recent): ?>
                <tr><td colspan="5"><small>No bookings yet.</small></td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="card">
        <h3>Bookings by status</h3>
        <?php foreach ($byStatus as $s => $n): ?>
            <div class="bar-row"><span><?= e(status_label($s)) ?></span>
                <div class="bar"><i class="s-<?= $s ?>" style="width:<?= round($n / $maxStatus * 100) ?>%"></i></div>
                <b><?= $n ?></b></div>
        <?php endforeach; ?>
    </div>
</section>
<?php $content = ob_get_clean(); include VIEWS_PATH . '/layout.php';
