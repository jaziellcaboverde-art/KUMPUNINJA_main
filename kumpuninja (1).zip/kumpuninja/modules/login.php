<?php
if (Auth::check()) { header('Location: ' . Auth::homeUrl()); exit; }
$error = flash('error');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $st = db()->prepare('SELECT * FROM users WHERE email = ? AND is_active = TRUE LIMIT 1');
    $st->execute([trim($_POST['email'] ?? '')]);
    $u = $st->fetch();
    if ($u && password_verify($_POST['password'] ?? '', $u['password_hash'])) {
        if ($u['role'] !== ROLE_ADMIN) {
            $error = 'Customer and provider portals are not built yet. Use the owner account.';
        } else {
            Auth::login($u);
            audit_log('login', "Login: {$u['email']}", 'user', (int)$u['id']);
            header('Location: ' . Auth::homeUrl()); exit;
        }
    } else {
        $error = 'Incorrect email or password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Log in — <?= APP_NAME ?></title>
<link rel="stylesheet" href="/assets/app.css">
</head><body class="auth-page">
<div class="auth-card">
    <div class="brand"><span class="brand-mark">K</span>
        <div><h1><?= APP_NAME ?></h1><p><?= e(BUSINESS_NAME) ?></p></div></div>
    <?php if ($error): ?><div class="alert"><?= e($error) ?></div><?php endif; ?>
    <form method="POST" action="/login">
        <?= csrf_field() ?>
        <label>Email</label>
        <input type="email" name="email" placeholder="owner@maz.test" required autofocus>
        <label>Password</label>
        <input type="password" name="password" required>
        <button class="btn" type="submit">Log in</button>
    </form>
</div>
</body></html>
