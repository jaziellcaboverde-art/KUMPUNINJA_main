<?php
// Tiny .env loader (Vercel provides real env vars, so this only fills gaps locally)
$envFile = dirname(__DIR__) . '/.env';
if (is_file($envFile)) {
    foreach (file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        if ($line[0] === '#' || !str_contains($line, '=')) continue;
        [$k, $v] = explode('=', $line, 2);
        if (getenv(trim($k)) === false) putenv(trim($k) . '=' . trim($v));
    }
}
define('APP_NAME', 'Kumpuninja');
define('BUSINESS_NAME', 'MAZ Plumbing and General Services');
define('VIEWS_PATH', dirname(__DIR__) . '/views');
define('ROLE_ADMIN', 'admin');
define('ROLE_PROVIDER', 'provider');
define('ROLE_CUSTOMER', 'customer');
define('BOOKING_STATUSES', ['pending', 'accepted', 'assigned', 'in_progress', 'completed', 'cancelled']);
date_default_timezone_set('Asia/Manila');
