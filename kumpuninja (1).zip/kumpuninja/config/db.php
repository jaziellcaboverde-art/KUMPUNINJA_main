<?php
function db(): PDO
{
    static $pdo = null;
    if ($pdo) return $pdo;
    $dsn = sprintf('pgsql:host=%s;port=%s;dbname=%s;sslmode=%s',
        getenv('DB_HOST') ?: 'localhost', getenv('DB_PORT') ?: '5432',
        getenv('DB_NAME') ?: 'postgres', getenv('DB_SSLMODE') ?: 'require');
    try {
        $pdo = new PDO($dsn, getenv('DB_USER') ?: 'postgres', getenv('DB_PASS') ?: '', [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => true, // required by the Supabase pooler
        ]);
        $pdo->exec("SET TIME ZONE 'Asia/Manila'");
    } catch (PDOException $e) {
        error_log($e->getMessage());
        http_response_code(500);
        exit('Database connection error. Check your .env file.');
    }
    return $pdo;
}
