<?php
function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function url(string $p = ''): string { return '/' . ltrim($p, '/'); }
function redirect(string $p): never { header('Location: ' . url($p)); exit; }
function peso($n): string { return '₱' . number_format((float)$n, 2); }

function csrf_field(): string {
    $_SESSION['csrf'] ??= bin2hex(random_bytes(32));
    return '<input type="hidden" name="csrf" value="' . e($_SESSION['csrf']) . '">';
}
function csrf_check(): void {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) { http_response_code(419); exit('Invalid form token.'); }
}
function flash(string $k, ?string $v = null): ?string {
    if ($v !== null) { $_SESSION['flash'][$k] = $v; return null; }
    $x = $_SESSION['flash'][$k] ?? null; unset($_SESSION['flash'][$k]); return $x;
}
function audit_log(string $action, string $desc = '', ?string $type = null, ?int $id = null): void {
    try {
        $u = Auth::user();
        db()->prepare('INSERT INTO audit_logs (user_id,user_name,user_role,action,description,entity_type,entity_id) VALUES (?,?,?,?,?,?,?)')
            ->execute([$u['id'] ?? null, $u['name'] ?? 'System', $u['role'] ?? '', $action, $desc, $type, $id]);
    } catch (Throwable) {}
}
function status_label(string $s): string { return ucwords(str_replace('_', ' ', $s)); }
