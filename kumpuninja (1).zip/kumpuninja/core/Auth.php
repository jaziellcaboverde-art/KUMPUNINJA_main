<?php
class Auth
{
    public static function login(array $u): void {
        session_regenerate_id(true);
        $_SESSION['user'] = ['id' => (int)$u['id'], 'name' => $u['name'], 'email' => $u['email'], 'role' => $u['role']];
    }
    public static function logout(): void { $_SESSION = []; session_destroy(); redirect('/login'); }
    public static function check(): bool { return isset($_SESSION['user']); }
    public static function user(): ?array { return $_SESSION['user'] ?? null; }
    public static function role(): ?string { return $_SESSION['user']['role'] ?? null; }

    public static function requireRole(string ...$roles): void {
        if (!self::check()) { flash('error', 'Please log in to continue.'); redirect('/login'); }
        if (!in_array(self::role(), $roles, true)) { http_response_code(403); exit('403 – Not allowed.'); }
    }
    public static function homeUrl(): string {
        return self::role() === ROLE_ADMIN ? url('/admin/dashboard') : url('/login'); // customer/provider portals: Step 4
    }
}
