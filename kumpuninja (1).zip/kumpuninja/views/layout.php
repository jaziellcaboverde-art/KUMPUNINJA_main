<?php
// Expects: $pageTitle, $activeNav, $content
$nav = [
    'dashboard' => ['/admin/dashboard', 'Dashboard', true],
    'bookings'  => ['/admin/bookings',  'Bookings',  false],
    'providers' => ['/admin/providers', 'Providers', false],
    'services'  => ['/admin/services',  'Services & Rates', false],
    'portfolio' => ['/admin/portfolio', 'Portfolio', false],
    'customers' => ['/admin/customers', 'Customers', false],
    'payments'  => ['/admin/payments',  'Payments', false],
    'reviews'   => ['/admin/reviews',   'Reviews', false],
];
$u = Auth::user();
?>
<!DOCTYPE html>
<html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($pageTitle) ?> — <?= APP_NAME ?></title>
<link rel="stylesheet" href="/assets/app.css">
</head><body>
<div class="shell">
    <aside class="sidebar">
        <div class="brand"><span class="brand-mark">K</span>
            <div><h1><?= APP_NAME ?></h1><p>Owner Console</p></div></div>
        <nav>
        <?php foreach ($nav as $key => [$href, $label, $ready]): ?>
            <?php if ($ready): ?>
                <a href="<?= $href ?>" class="<?= $activeNav === $key ? 'active' : '' ?>"><?= e($label) ?></a>
            <?php else: ?>
                <span class="soon"><?= e($label) ?> <small>soon</small></span>
            <?php endif; ?>
        <?php endforeach; ?>
        </nav>
        <div class="who"><strong><?= e($u['name']) ?></strong><br><a href="/logout">Log out</a></div>
    </aside>
    <main class="main">
        <header class="topbar"><h2><?= e($pageTitle) ?></h2><span><?= date('l, F j, Y') ?></span></header>
        <?= $content ?>
    </main>
</div>
</body></html>
